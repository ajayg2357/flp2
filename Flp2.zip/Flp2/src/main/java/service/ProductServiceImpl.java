package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import bean.ProductBean;
import dao.ProductDaoImpl;
import exception.ProductException;

public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDaoImpl dao;

	@Override
	public ProductBean addProduct(ProductBean product) throws ProductException {
		try {
			return dao.save(product);
		} catch (Exception e) {

			throw new ProductException();
		}
	}

	@Override
	public List<ProductBean> viewAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

}
