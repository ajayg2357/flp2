package service;

import java.util.List;



import bean.ProductBean;
import exception.ProductException;

public interface ProductService {

	public ProductBean addProduct(ProductBean product) throws ProductException;
	List<ProductBean> viewAll();

}
