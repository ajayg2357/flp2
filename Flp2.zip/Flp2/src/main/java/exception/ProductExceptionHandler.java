package exception;

public class ProductExceptionHandler {

}
