package com.capg.Flp2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Flp2Application {

	public static void main(String[] args) {
		SpringApplication.run(Flp2Application.class, args);
	}

}
