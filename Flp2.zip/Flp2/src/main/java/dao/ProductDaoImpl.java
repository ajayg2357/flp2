package dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import bean.ProductBean;

@Repository
public interface ProductDaoImpl extends JpaRepository<ProductBean, Integer> {

}
